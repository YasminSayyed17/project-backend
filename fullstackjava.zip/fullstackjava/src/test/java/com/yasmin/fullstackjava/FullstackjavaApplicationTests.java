package com.yasmin.fullstackjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullstackjavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
