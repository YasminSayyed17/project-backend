package com.yasmin.fullstackjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FullstackjavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FullstackjavaApplication.class, args);
	}

}
